show databases
use employee_data
show tables
select * from bank_transactions;
Q1: How many total transactions are in the 
select count(*)as total_transactions from bank_transactions;

2️ Find the total deposited amount
Question: What is the total sum of all deposits?

select * from bank_transactions
select sum(amount) as total_all_deposits 
from bank_transactions

3️ Show the earliest and latest transaction dates
Question: What are the first and last transaction dates in the dataset?
select * from bank_transactions
select MIN(transaction_date) as last_transaction, MAX(transaction_date)as first_transaction
 from bank_transactions;

________________________________________
4️ Find the highest withdrawal
Question: Which transaction had the largest withdrawal amount?

select * from bank_transactions

select MAX(amount) as largest_withdrawal_amount
from bank_transactions
where transaction_type = 'withdrawal'

5️ List all unique account types
Question: What account types exist in the bank?

select * from bank_transactions;
select distinct(account_type) as unique_accounttypes
from bank_transactions;

6️ Total balance per branch
Question: What is the sum of balances for each branch?
select * from bank_transactions;
select branch_name, sum(amount) as Total_balance_per_branch
from bank_transactions
group by branch_name ORDER BY Total_balance_per_branch;

select branch_name, sum(amount) as Total_balance_per_branch
from bank_transactions
group by branch_name ORDER BY Total_balance_per_branch DESC LIMIT 1;

________________________________________
7️.Find customers with more than 5 transactions
Question: Which customers made more than 5 transactions?

SELECT * FROM BANK_TRANSACTIONS

select customer_name, count(transaction_date) as more_than_5_transactions
from bank_transactions
group by customer_name having (*)>5 ORDER BY more_than_5_transactions desc;

SELECT customer_name, COUNT(transaction_date) AS transaction_count
FROM bank_transactions
GROUP BY customer_name
HAVING COUNT(transaction_date) > 5
ORDER BY transaction_count DESC;

8️.Get top 5 biggest transactions
Question: Which are the top 5 transactions by amount?

select amount as top5
from bank_transactions
order by amount DESC limit 5;

9️.Show monthly transaction count
Question: How many transactions happened per month?

select * from bank_transactions

select transaction_date, count(*) as Month_wise
from bank_transactions
group by transaction_date having count(*) order by Month_wise DESC; --this wrong

SELECT 
    DATE_FORMAT(transaction_date, '%Y-%m') AS month,
    COUNT(*) AS total_transactions
FROM bank_transactions
GROUP BY month
ORDER BY month;
🔟 Find accounts with balance below 1000
Question: Which accounts have a balance after transaction below ₹1000?

select * from bank_transactions;

select * from bank_transactions
where balance_after <= 1000;

1️ Select all transactions
Q: Show all columns from the bank_transactions table.

select * from bank_transactions
2️ Filter by account type
Q: Show all transactions for account type 'Savings'.
select * from bank_transactions
where account_type = 'savings';

Show transaction_id, customer_name, amount for deposits only.

select transaction_id, customer_name, transaction_type, amount
from bank_transactions
where transaction_type = 'Deposit'

4️ Transactions above ₹50,000
Q: Show all transactions where amount > 50000.
select * from bank_transactions

5️ Largest single transaction
Q: Find the highest transaction amount.
select MAX(amount) from bank_transactions


where amount > 50000;

6️.Smallest single transaction
Q: Find the lowest transaction amount.
select MIN(amount) as Smallest from bank_transactions

select * from bank_transactions
select sum(amount) as total_ts
from bank_transactions

8️ 
Q: Find the average transaction amount.
select AvG(amount) as AV_tas
from bank_transactions

9️ -Count total transactions
Q: How many transactions are there in total

select count(*)
from bank_transactions;

🔟 Transactions per account type
Q: How many transactions per account type?
select * from Bank_transactions

select account_type, count(*) AS transaction_count
from bank_transactions
GROUP BY Account_type having count(*) order by account_type;

•  How many transactions were made by each customer?
select customer_name, count(*) AS transactions_each_customer
from bank_transactions
GROUP BY customer_name;
select * from bank_transactions;
•  What is the total transaction amount for each account type?
select account_type, count(*)
from bank_transactions
GROUP BY account_type;
select * from bank_transactions;
•  What is the average transaction amount for each branch?
select Branch_name, AVG(amount), count(*)
from bank_transactions
GROUP BY branch_name;
•  What is the highest transaction amount for each customer?
select * from bank_transactions;

select customer_name, MAX(amount) as highest_amount
from bank_transactions
group by customer_name order by highest_amount DESC LIMIT 1;

•  What is the lowest transaction amount for each month?

select 
    DATE_FORMAT(transaction_date, '%Y-%m') AS month, 
	MIN(amount) AS lowest_amount
from bank_transactions
group by month 
order by lowest_amount ASC
LIMIT 3;

SELECT 
    DATE_FORMAT(transaction_date, '%Y-%m') AS month, 
    MIN(amount) AS lowest_amount
FROM bank_transactions
GROUP BY month
ORDER BY lowest_amount ASC
LIMIT 3;

transaction_date, MIN(amount) as lowest_amount
from bank_transactions
group by transaction_date order by lowest_amount ASC LIMIT 3;

•  How many accounts are there in each branch?
select * from bank_transactions;

select branch_name, count(*) as ineach_branch
from bank_transactions
group by branch_name;

•  How many transactions occurred for each transaction type?
select * from bank_transactions;
select transaction_type, count(*) as transaction_count
from bank_transactions
group by transaction_type;

•  What is the total deposit amount for each customer?
select * from bank_transactions;

select sum(amount) As Total_deposit_amount, transaction_type
from bank_transactions
group by transaction_type having transaction_type = 'Deposit'

select customer_name, count(*) as total_deposit
from bank_transactions
where transaction_type = 'Deposit' 
group by customer_name;

•  What is the total transaction amount for each month?
select * from bank_transactions;

select sum(amount),
Date_format(transaction_date,'%Y-%M') as month
from bank_transaction
group by month;
SELECT 
    DATE_FORMAT(transaction_date, '%Y-%m') AS month, 
    sum(amount) AS total_amount
FROM bank_transactions
GROUP BY month

•  Which customers have made more than 3 transactions?

select customer_name, count(*) as transactions_count
from bank_transactions
Group by Customer_name
having transactions_count >3


1️⃣1️⃣ Monthly transaction count
Q: How many transactions happened each month?
SELECT 
    DATE_FORMAT(transaction_date, '%Y-%m') AS month, 
    count(*) AS total_transactions_mothwise
FROM bank_transactions
GROUP BY month


select * from bank_transactions
use emoloyee_data
show databases

________________________________________
1️⃣2️⃣Customers with more than 5 transactions

select customer_name, count(*) as Total_transactions
from bank_transactions
group by customer_name having Total_transactions > 5
ORDER BY Total_transactions ;

use employee_data

1️⃣3️⃣ Highest spender
Q: Which customer spent the most money (Withdrawals only)?
select * from bank_transactions

select customer_name, count(*) as total_transactions, SUM(AMOUNT) as total_spent
from bank_transactions
where transaction_type = 'withdrawal'
Group by customer_name ORDER BY total_transactions DESC LIMIT 1;

SELECT customer_name, SUM(amount) AS total_spent
FROM bank_transactions
WHERE transaction_type = 'Withdrawal'
GROUP BY customer_name
ORDER BY total_spent DESC
LIMIT 1;

1️⃣4️⃣ Largest deposit per customer
Q: Show each customer's largest single deposit.'

SELECT customer_name, MAX(amount) AS largest_deposit
FROM bank_transactions
WHERE transaction_type = 'Deposit'
GROUP BY customer_name;

1️⃣5️⃣ Branch with highest total deposits
Q: Which branch collected the most in deposits?

