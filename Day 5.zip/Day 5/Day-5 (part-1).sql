🔢 COUNT() – Questions
show databases;
use student_info
select * from products;

1.	Count the total number of products.
select count(name) from products;
2.	Count how many products have a non-null price.
select count(price) from products
where price is null;
select count(price) from products
where price = 'null';

4.	Count the number of products where category is 'Laptop'.
select count (category) from products
where category = 'laptop';

select * from products
SELECT COUNT(*) FROM products
WHERE category = 'Laptop';

5.	Count the number of products added in 2025.
select count(*) from products
where created_at between '2025-01-12' and '2025-12-30'
________________________________________
➕ SUM() – Questions
6.	Find the total price of all products.
select sum(price) from products;
7.	Calculate the total stock across all products.
select sum(price) from products

8.	Find the total price of all products in the 'Mobile' category.

9.	Calculate the total value of inventory (price × stock is not allowed yet – will do later in SELECT expressions).

________________________________________
📊 AVG() – Questions
10.	Find the average price of all products.
select avg (price) from products;
11.	What is the average stock per product?
select AVG(price) from products;
12.	Find the average price of products in the 'Accessories' category.
select avg(*) from products
where category = 'Accessories'
________________________________________
🔼 MIN() / 🔽 MAX() – Questions
13.	Find the cheapest product price.
select min(price) from products;
14.	Find the most expensive product price.
select MAX(price) from products;
15.	What is the lowest stock quantity among all products?


