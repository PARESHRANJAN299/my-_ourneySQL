🔢 COUNT() – Questions
show databases
use student_info
select * from products
1.Count the total number of products.
select sum(price) from products;	
2.Count how many products have a non-null price.
select count(price)from products 
where price is null;
select count(price) from products
where price is null;
3.Count how many products are in stock (stock > 0).
select count(category)
from products
where category = 'laptop';
4.Count the number of products where category is 'Laptop'.
select count(category) as laptop
from products
where category = 'laptop';
5.Count the number of products added in 2025.
select count(name) as new_products from products
where created_at between '2025-01-01' and '2025-12-31'
________________________________________
--➕SUM()–Questions

6.	Find the total price of all products.

select sum(price) from products;
7.	Calculate the total stock across all products.

8.	Find the total price of all products in the 'Mobile' category.
9.	Calculate the total value of inventory (price × stock is not allowed yet – will do later in SELECT expressions).
________________________________________
📊 AVG() – Questions
10.	Find the average price of all products.
11.	What is the average stock per product?
12.	Find the average price of products in the 'Accessories' category.
________________________________________
🔼 MIN() / 🔽 MAX() – Questions
13.	Find the cheapest product price.
14.	Find the most expensive product price.
15.	What is the lowest stock quantity among all products?

show databases;
use student_info
➕ SUM() – Advanced Use
6.	Find the sum of prices for all products that contain "Mouse" in their name.
select sum(price)from products
where name like '%mouse%';
7.	Find the total stock for products priced under ₹5,000.

select sum(price) from products
where price <= 5000;
8.	Find the sum of prices for all products that are not in the 'Accessories' category.


select sum(price) from products
where category <> 'Accessories';
________________________________________

📊 AVG() – Advanced Use
9.	Find the average price of all products priced over ₹5,000.
select avg(price) from products
where price <= 5000;
10.	Find the average stock of products whose name starts with 'Laptop'.
select AVG(price)from products
where name like 'laptop%';
11.	Find the average price of all products excluding 'Laptop' category.

select AVG(price)from products
where not name like 'laptop%';

🔼 MIN() / 🔽 MAX() – Advanced Use
12.	Find the lowest price among products added in 2024.
select MIN(price) from products
where created_at between '2024-01-01' and '2024-12-31'
13.	Find the highest price among products whose category is 'Laptop'.
select MAX(price) from products
where category = 'laptop'
14.	Find the oldest created_at date in the table.
select min(created_at) from products;
15.	Find the most recent created_at date in the table.
SELECT 
    MIN(created_at) AS earliest_date,
    MAX(created_at) AS most_recent_date
FROM products;
